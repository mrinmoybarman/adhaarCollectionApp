// export const BASE_URL = 'https://adhaarapi.mrinweb.xyz/public/api';
export const BASE_URL = 'http:localhost:8000/api';