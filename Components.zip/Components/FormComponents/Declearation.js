import React, { useContext, useState } from "react";
import {
  Button,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import BouncyCheckbox from "react-native-bouncy-checkbox";

import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Ionicons from "react-native-vector-icons/Ionicons";
import { FormContext } from "../../Context/FormContext";

function Declearation(props) {
  const [toggleCheckBox, setToggleCheckBox] = useState(false);
  const {formData,finalSubmit} = useContext(FormContext);

  return (
    <>
      <View style={{ flex: 1, padding: 10 }}>
        <View
          style={{
            flex: 1,
            backgroundColor: "#0002",
            borderRadius: 10,
            padding: 10,
            opacity: 1,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              paddingBottom: 10,
            }}
          >
            <View style={{flex:1}}>
              <Text style={styles.topTilte2}>
                Details Filled for -PMYAG, MGNREGA, SAP
              </Text>
              <Text style={styles.topTilte4}>You can Preview the form or submit Directly</Text>
              <View>
                <TouchableOpacity style={styles.buttonsecondary} onPress={()=>{console.log("goint to preveiew")}}>
                  <View style={{flexDirection:'row',paddingHorizontal:20}}>
                  <Text
                    style={{
                      color: "white",
                      textAlign: "left",
                      fontWeight: "bold",
                      flex:1
                    }}
                  >
                    Preview
                  </Text>
                  <MaterialIcons
                      name="arrow-forward-ios"
                      size={22}
                      color="#fff"
                  />
                  </View>
                </TouchableOpacity>
                <View style={{flexDirection:'row',justifyContent:'center',marginVertical:40}}>
                  <Text style={{fontSize:40,fontWeight:'bold'}}>--OR--</Text>
                </View>
              </View>

              <View style={{flexDirection:'row',justifyContent:'center',alignItems:'center',
              flex:1,marginVertical:0,paddingHorizontal:20}}>
                <BouncyCheckbox
                  size={35}
                  fillColor="green"
                  unfillColor="#FFFFFF"
                  iconStyle={{ borderColor: "red" }}
                  innerIconStyle={{ borderWidth: 5 }}
                  onPress={(isChecked) => {
                    setToggleCheckBox(isChecked);
                  }}
                ></BouncyCheckbox>
                <Text style={{marginVertical:10,fontSize:18,fontWeight:'bold'}}>
                  I hereby declare that the details provided are verified.
                </Text>
              </View>
            {toggleCheckBox && (
              <View style={{marginVertical:40}}>
                <TouchableOpacity style={styles.button1} onPress={()=>finalSubmit()}>
                  <Text
                    style={{
                      color: "white",
                      textAlign: "center",
                      fontWeight: "bold",
                    }}
                  >
                    Submit
                    <MaterialIcons
                      name="arrow-forward-ios"
                      size={12}
                      color="#fff"
                    />
                  </Text>
                </TouchableOpacity>
              </View>
            )}
              
            </View>
          </View>
        </View>
      </View>
    </>
  );
}

export default Declearation;



const styles = StyleSheet.create({
    topTilte1: {
      fontSize: 16,
      fontWeight: "bold",
    },
    topTilte2: {
      fontSize: 25,
      fontWeight: "bold",
      marginVertical: 20,
    },
    topTilte4:{
      fontSize: 20,
      fontWeight: "bold",
      marginVertical: 18,
      paddingHorizontal: 10
    },
    buttonsecondary: {
      fontSize: 16,
      fontWeight: "bold",
      borderRadius: 15,
      borderWidth: 2,
      borderColor: "#000",
      padding: 10,
      backgroundColor: "#04aa6d",
    },
    button1: {
      fontSize: 16,
      fontWeight: "bold",
      borderRadius: 15,
      borderWidth: 2,
      borderColor: "#000",
      padding: 10,
      backgroundColor: "#007bff",
    },
    button2: {
      fontSize: 16,
      fontWeight: "bold",
      borderRadius: 15,
      borderWidth: 2,
      borderColor: "#000",
      padding: 10,
      backgroundColor: "#dc3545",
    },
    buttonContainer: {
      flex: 1,
      marginTop: 10,
      height: 45,
      justifyContent: "center",
      alignItems: "center",
      marginBottom: 20,
      marginHorizontal: 20,
      borderRadius: 30,
      backgroundColor: "#fff",
      color: "#000",
    },
  });
  
