import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useEffect, useState } from "react";
import { BASE_URL } from "./../Config";
export const FormContext = createContext();

export const FormProvider = ({ children }) => {
    const [formData, setFormData] = useState({});
    const [d1, setD1] = useState('');
    const [d2, setD2] = useState('');
    const [d3, setD3] = useState('');

    console.log('Form Context', formData);

    // baad me karenge
    //   const setPmaygData = (data) =>{
    //         setFormData({...prevData,data});
    //   }

    //   const setMgnregaData = (data) =>{
    //     setFormData({...prevData,data});
    //   }

    //   const setSapData = (data) =>{
    //     setFormData({...prevData,data});
    //   }

    const fileSubmit = async (file) => {
        try {
            let userToken = await AsyncStorage.getItem("userToken");
            let filename = file.uri.split('/').pop();  // we will pass it later
            let match = /\.(\w+)$/.exec(filename);
            let type = match ? `image/${match[1]}` : `image`;
            // let type = 'image';
            let formData = new FormData();
            formData.append('photo', { uri: file.uri, name: filename, type });
            try {
                const response= await fetch(`${BASE_URL}/submit`, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'content-type': 'multipart/form-data',
                        Authorization: `Bearer ${userToken}`
                    }
                })
                    .then(async(response) => await response.json())
                    .then(async (json) => {
                        console.log("file submit", json.data);
                        return await json.data;
                    });
            } catch (error) {
                console.error(`Login Error ${error}`);
                return error;
            }
        } catch (error) {
            console.error(error);
        };
    }


    const submitPmaygData=(data) => {
        let benificiaryName = data.benificiaryName;
        let pmaygid = data.pmaygid;
        let isAdhaar = data.isAdhaar;
        // checking household have pmayg benificiary
        if (data.isAdhaar) {
            const aadharNo = data.aadharNo;
            const aadharDocFront =fileSubmit(data.aadharDocFront);
            const aadharDocBack = fileSubmit(data.aadharDocBack);
            const consentDoc = fileSubmit(data.consentDoc);

            console.log(aadharDocFront);
            console.log(aadharDocBack);
            console.log(consentDoc);

            // return { 
            //     aadharNo:aadharNo,
            //     aadharDocFront:aadharDocFront,
            //     aadharDocBack:aadharDocBack,
            //     consentDoc:consentDoc 
            // };
        }
    }

    const finalSubmit = () => {
        // first check for pmayg
        if (formData.pmaygData.hasPmayg) {
            const result = submitPmaygData(formData.pmaygData);
            console.log("response from server", result);
        }
    }


    return (
        <FormContext.Provider
            value={{ formData, finalSubmit, setFormData }}
        >
            {children}
        </FormContext.Provider>
    );
};
